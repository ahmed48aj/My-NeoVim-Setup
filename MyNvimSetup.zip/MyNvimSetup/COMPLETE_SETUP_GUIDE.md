# 🚀 Complete Neovim Setup Guide (Ahmed's Configuration)

This guide will help you replicate my **exact** Neovim setup, including all configurations, plugins, themes, and custom modifications.

## 📋 Prerequisites

Before starting, make sure you have the following installed:

### Required Software
- **Neovim 0.11+** (I'm using v0.11.3)
- **Git** (version 2.43.0+)
- **Node.js** (I'm using v18.19.1)
- **Python 3.12+** (I'm using Python 3.12.3)
- **Curl** or **wget**
- **A Nerd Font** (for icons)

### Install Prerequisites (Ubuntu/Debian)
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Neovim (latest version)
curl -LO https://github.com/neovim/neovim/releases/latest/download/nvim-linux64.tar.gz
sudo rm -rf /opt/nvim
sudo tar -C /opt -xzf nvim-linux64.tar.gz
echo 'export PATH="$PATH:/opt/nvim-linux64/bin"' >> ~/.bashrc
source ~/.bashrc

# Install other dependencies
sudo apt install -y git curl python3 python3-pip nodejs npm

# Install Python development tools
pip3 install --user pynvim debugpy black mypy ruff

# Install Node.js packages for LSP
npm install -g neovim
```

### Install a Nerd Font
```bash
# Download and install JetBrainsMono Nerd Font
wget https://github.com/ryanoasis/nerd-fonts/releases/download/v3.0.2/JetBrainsMono.zip
unzip JetBrainsMono.zip -d ~/.fonts/
fc-cache -fv
```

## 🎯 Installation Methods

### Method 1: Clone My Exact Configuration (Recommended)

**Step 1: Backup existing config (if any)**
```bash
# Backup your current nvim config
mv ~/.config/nvim ~/.config/nvim.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
mv ~/.local/share/nvim ~/.local/share/nvim.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
mv ~/.cache/nvim ~/.cache/nvim.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
```

**Step 2: Clone my configuration**
```bash
# Clone NvChad base (v2.0 branch)
git clone --depth 1 --branch v2.0 https://github.com/NvChad/NvChad ~/.config/nvim

# Remove the default .git to make it your own
rm -rf ~/.config/nvim/.git
```

**Step 3: Apply my custom configurations**

Create the custom directory and files:

```bash
mkdir -p ~/.config/nvim/lua/custom/configs
```

Create `~/.config/nvim/lua/custom/init.lua`:
```lua
-- Custom init.lua for additional Python functionality

-- Python run mappings
vim.keymap.set('n', '<leader>pr', function()
  local file = vim.fn.expand('%')
  if file ~= '' then
    vim.cmd('!python3 ' .. file)
  else
    print("No file to run")
  end
end, { desc = "Run Python File" })

vim.keymap.set('n', '<leader>pt', function()
  local file = vim.fn.expand('%')
  if file ~= '' then
    vim.cmd('terminal python3 ' .. file)
  else
    print("No file to run")
  end
end, { desc = "Run Python in Terminal" })

-- Additional useful Python mappings
vim.keymap.set('n', '<leader>pi', function()
  vim.cmd('terminal python3 -i ' .. vim.fn.expand('%'))
end, { desc = "Run Python Interactive" })

-- Create a quick run command for Python
vim.api.nvim_create_user_command('PyRun', function()
  local file = vim.fn.expand('%')
  if file ~= '' and vim.bo.filetype == 'python' then
    vim.cmd('!python3 ' .. file)
  else
    print("Not a Python file or no file open")
  end
end, { desc = "Run current Python file" })

-- Create a command for Python in terminal
vim.api.nvim_create_user_command('PyTerm', function()
  local file = vim.fn.expand('%')
  if file ~= '' and vim.bo.filetype == 'python' then
    vim.cmd('terminal python3 ' .. file)
  else
    print("Not a Python file or no file open")
  end
end, { desc = "Run current Python file in terminal" })

print("Custom Python mappings loaded!")

-- ===============================
-- Shiny NvimTree Highlights
-- ===============================

-- Function to set shiny highlights for NvimTree
local function set_nvimtree_highlights()
  -- Shiny gold/yellow highlight for current file
  vim.api.nvim_set_hl(0, "NvimTreeCursorLine", {
    bg = "#FFD700",  -- Gold background
    fg = "#000000",  -- Black text for contrast
    bold = true,
  })
  
  -- Bright cyan for focused file
  vim.api.nvim_set_hl(0, "NvimTreeFocusedFile", {
    fg = "#00FFFF",  -- Bright cyan
    bg = "#1A1A1A",  -- Dark background
    bold = true,
    italic = true,
  })
  
  -- Bright green for open files
  vim.api.nvim_set_hl(0, "NvimTreeOpenedFile", {
    fg = "#00FF00",  -- Bright green
    bold = true,
  })
  
  -- Electric blue for modified files
  vim.api.nvim_set_hl(0, "NvimTreeModifiedFile", {
    fg = "#1E90FF",  -- Electric blue
    bold = true,
  })
  
  -- Bright magenta for executable files
  vim.api.nvim_set_hl(0, "NvimTreeExecFile", {
    fg = "#FF00FF",  -- Bright magenta
    bold = true,
  })
  
  -- Glowing orange for special files
  vim.api.nvim_set_hl(0, "NvimTreeSpecialFile", {
    fg = "#FF4500",  -- Orange red
    bold = true,
    italic = true,
  })
  
  -- Bright white for root folder
  vim.api.nvim_set_hl(0, "NvimTreeRootFolder", {
    fg = "#FFFFFF",  -- Bright white
    bold = true,
    underline = true,
  })
  
  -- Shiny purple for git staged files
  vim.api.nvim_set_hl(0, "NvimTreeGitStaged", {
    fg = "#9932CC",  -- Dark orchid
    bold = true,
  })
  
  -- Glowing red for git deleted files
  vim.api.nvim_set_hl(0, "NvimTreeGitDeleted", {
    fg = "#FF0000",  -- Bright red
    bold = true,
    strikethrough = true,
  })
end

-- Apply highlights immediately
set_nvimtree_highlights()

-- Re-apply highlights when colorscheme changes
vim.api.nvim_create_autocmd("ColorScheme", {
  pattern = "*",
  callback = function()
    set_nvimtree_highlights()
  end,
  desc = "Apply shiny NvimTree highlights after colorscheme change"
})

print("Shiny NvimTree highlights loaded!")

-- ===============================
-- Custom Comment Color
-- ===============================

-- Function to set custom comment color (more aggressive)
local function set_comment_color()
  -- Force override with high priority
  vim.api.nvim_set_hl(0, 'Comment', {
    fg = '#ff0000',  -- BRIGHT RED for maximum visibility
    bg = 'NONE',     -- Transparent background
    italic = true,   -- Make comments italic
    bold = true,     -- Make comments bold
    force = true     -- Force the change
  })
  
  -- Also try alternative comment highlights
  vim.api.nvim_set_hl(0, '@comment', {
    fg = '#ff0000',
    bg = 'NONE',
    italic = true,
    bold = true,
    force = true
  })
  
  vim.api.nvim_set_hl(0, '@comment.python', {
    fg = '#ff0000',
    bg = 'NONE', 
    italic = true,
    bold = true,
    force = true
  })
end

-- Apply comment color immediately
set_comment_color()

-- Re-apply comment color when colorscheme changes
vim.api.nvim_create_autocmd("ColorScheme", {
  pattern = "*",
  callback = function()
    -- Delay to let NvChad finish loading
    vim.defer_fn(function()
      set_comment_color()
    end, 100)
  end,
  desc = "Apply custom comment color after colorscheme change"
})

-- Apply after everything loads with multiple attempts
vim.api.nvim_create_autocmd("VimEnter", {
  pattern = "*",
  callback = function()
    -- Try multiple times with increasing delays
    for i = 1, 5 do
      vim.defer_fn(function()
        set_comment_color()
      end, i * 200)
    end
  end,
  desc = "Apply custom comment color after startup"
})

-- Also try when entering a buffer
vim.api.nvim_create_autocmd("BufEnter", {
  pattern = "*.py",
  callback = function()
    vim.defer_fn(function()
      set_comment_color()
    end, 50)
  end,
  desc = "Apply custom comment color when entering Python files"
})

-- Create a manual command to force comment color change
vim.api.nvim_create_user_command('FixComments', function()
  vim.api.nvim_set_hl(0, 'Comment', {
    fg = '#ff0000',  -- BRIGHT RED
    bg = 'NONE',
    italic = true,
    bold = true
  })
  vim.api.nvim_set_hl(0, '@comment', {
    fg = '#ff0000',
    bg = 'NONE', 
    italic = true,
    bold = true
  })
  print("Comment color forced to RED!")
end, { desc = "Manually fix comment colors" })

print("Custom comment color loaded!")
```

**Step 4: Replace init.lua with transparency settings**
```bash
# Replace the main init.lua file
cat > ~/.config/nvim/init.lua << 'EOF'
require "core"

local custom_init_path = vim.api.nvim_get_runtime_file("lua/custom/init.lua", false)[1]

if custom_init_path then
  dofile(custom_init_path)
end

require("core.utils").load_mappings()

local lazypath = vim.fn.stdpath "data" .. "/lazy/lazy.nvim"

-- bootstrap lazy.nvim!
if not vim.loop.fs_stat(lazypath) then
  require("core.bootstrap").gen_chadrc_template()
  require("core.bootstrap").lazy(lazypath)
end

dofile(vim.g.base46_cache .. "defaults")
vim.opt.rtp:prepend(lazypath)
require "plugins"

-- ===============================
-- Transparent background for Neovim
-- ===============================

-- Function to set transparency for all relevant highlights
local function set_transparency()
    local groups = {
        "Normal",
        "NormalNC",
        "SignColumn",
        "VertSplit",
        "StatusLine",
        "StatusLineNC",
        "LineNr",
        "NonText",
        "CursorLine",
        "ColorColumn",
        "Pmenu",
        "PmenuSel",
        "TabLine",
        "TabLineSel",
        "TabLineFill",
        "MsgArea"
    }
    for _, group in ipairs(groups) do
        vim.api.nvim_set_hl(0, group, { bg = "none" })
    end
end

-- Apply transparency immediately
set_transparency()

-- Re-apply transparency whenever a colorscheme is loaded
vim.api.nvim_create_autocmd("ColorScheme", {
    pattern = "*",
    callback = function()
        set_transparency()
    end
})
EOF
```

**Step 5: Create custom plugins configuration**
```bash
cat > ~/.config/nvim/lua/custom/plugins.lua << 'EOF'
local plugins = {
  {
    "nvim-neotest/nvim-nio",
  },
  {
    "rcarriga/nvim-dap-ui",
    dependencies = "mfussenegger/nvim-dap",
    config = function()
      local dap = require("dap")
      local dapui = require("dapui")
      dapui.setup()
      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end
    end
  },
  {
    "mfussenegger/nvim-dap",
    config = function(_, opts)
      require("core.utils").load_mappings("dap")
    end
  },
  {
    "mfussenegger/nvim-dap-python",
    ft = "python",
    dependencies = {
      "mfussenegger/nvim-dap",
      "rcarriga/nvim-dap-ui",
      "nvim-neotest/nvim-nio",
    },
    config = function(_, opts)
      local path = "~/.local/share/nvim/mason/packages/debugpy/venv/bin/python"
      require("dap-python").setup(path)
      require("core.utils").load_mappings("dap_python")
    end,
  },
  {
    "nvimtools/none-ls.nvim",
    ft = {"python"},
    opts = function()
      return require "custom.configs.null-ls"
    end,
  },
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "black",
        "debugpy",
        "mypy",
        "ruff",
        "pyright",
      },
    },
  },
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig"
      require "custom.configs.lspconfig"
    end,
  },
  {
    "nvim-tree/nvim-tree.lua",
    opts = function()
      local default_opts = require "plugins.configs.nvimtree"
      
      -- Enhanced configuration for shiny highlights
      default_opts.renderer = vim.tbl_deep_extend("force", default_opts.renderer or {}, {
        highlight_git = true,
        highlight_opened_files = "name",
        highlight_modified = "name",
        special_files = {
          "Cargo.toml",
          "Makefile",
          "README.md",
          "readme.md",
          "CMakeLists.txt",
          "package.json",
          "requirements.txt",
          "setup.py",
          "pyproject.toml",
        },
        icons = {
          show = {
            file = true,
            folder = true,
            folder_arrow = true,
            git = true,
            modified = true,
          },
          glyphs = {
            default = "󰈚",
            symlink = "",
            modified = "●",
            folder = {
              default = "",
              open = "",
              empty = "",
              empty_open = "",
              symlink = "",
              symlink_open = "",
              arrow_open = "",
              arrow_closed = "",
            },
            git = {
              unstaged = "✗",
              staged = "✓",
              unmerged = "",
              renamed = "➜",
              untracked = "★",
              deleted = "",
              ignored = "◌",
            },
          },
        },
      })
      
      -- Enable git integration for better highlights
      default_opts.git = vim.tbl_deep_extend("force", default_opts.git or {}, {
        enable = true,
        ignore = false,
        show_on_dirs = true,
        show_on_open_dirs = true,
      })
      
      return default_opts
    end,
  },
}
return plugins
EOF
```

**Step 6: Create custom mappings**
```bash
cat > ~/.config/nvim/lua/custom/mappings.lua << 'EOF'
local M = {}

M.dap = {
  plugin = true,
  n = {
    ["<leader>db"] = {"<cmd> DapToggleBreakpoint <CR>", "Toggle Breakpoint"},
    ["<leader>dc"] = {"<cmd> DapContinue <CR>", "Start/Continue Debugging"},
    ["<leader>dr"] = {"<cmd> DapRestart <CR>", "Restart Debugging"},
    ["<leader>dt"] = {"<cmd> DapTerminate <CR>", "Terminate Debugging"},
    ["<leader>dso"] = {"<cmd> DapStepOver <CR>", "Step Over"},
    ["<leader>dsi"] = {"<cmd> DapStepInto <CR>", "Step Into"},
    ["<leader>dsO"] = {"<cmd> DapStepOut <CR>", "Step Out"},
    ["<leader>du"] = {"<cmd> lua require'dapui'.toggle() <CR>", "Toggle Debug UI"},
  }
}

M.dap_python = {
  plugin = true,
  n = {
    ["<leader>dpr"] = {
      function()
        require('dap-python').test_method()
      end,
      "Debug Python Test Method"
    },
    ["<leader>dpc"] = {
      function()
        require('dap-python').test_class()
      end,
      "Debug Python Test Class"
    },
    ["<leader>dpf"] = {
      function()
        require('dap-python').debug_selection()
      end,
      "Debug Python Selection"
    }
  }
}

M.python = {
  n = {
    ["<leader>pr"] = {"<cmd> !python3 % <CR>", "Run Python File"},
    ["<leader>pt"] = {"<cmd> terminal python3 % <CR>", "Run Python in Terminal"},
  }
}

-- Diagnostic mappings
M.diagnostics = {
  n = {
    ["<leader>e"] = {
      function()
        vim.diagnostic.open_float()
      end,
      "Show diagnostic error messages"
    },
    ["[d"] = {
      function()
        vim.diagnostic.goto_prev()
      end,
      "Go to previous diagnostic message"
    },
    ["]d"] = {
      function()
        vim.diagnostic.goto_next()
      end,
      "Go to next diagnostic message"
    },
    ["<leader>q"] = {
      function()
        vim.diagnostic.setloclist()
      end,
      "Open diagnostics list"
    },
  }
}

-- General insert mode mappings
M.general = {
  i = {
    ["jj"] = { "<ESC>", "Exit insert mode" },
  }
}

return M
EOF
```

**Step 7: Create custom LSP and null-ls configs**
```bash
# Create null-ls config
cat > ~/.config/nvim/lua/custom/configs/null-ls.lua << 'EOF'
local augroup = vim.api.nvim_create_augroup("LspFormatting", {})
local null_ls = require("null-ls")

local opts = {
  sources = {
    null_ls.builtins.formatting.black,
    null_ls.builtins.formatting.isort,
    null_ls.builtins.diagnostics.mypy,
    null_ls.builtins.diagnostics.ruff,
  },
  on_attach = function(client, bufnr)
    if client.supports_method("textDocument/formatting") then
      vim.api.nvim_clear_autocmds({
        group = augroup,
        buffer = bufnr,
      })
      vim.api.nvim_create_autocmd("BufWritePre", {
        group = augroup,
        buffer = bufnr,
        callback = function()
          vim.lsp.buf.format({ bufnr = bufnr })
        end,
      })
    end
  end,
}
return opts
EOF

# Create custom lspconfig
cat > ~/.config/nvim/lua/custom/configs/lspconfig.lua << 'EOF'
local config = require("plugins.configs.lspconfig")
local on_attach = config.on_attach
local capabilities = config.capabilities

local lspconfig = require("lspconfig")

-- Enhanced Python LSP with additional features
lspconfig.pyright.setup({
  on_attach = on_attach,
  capabilities = capabilities,
  filetypes = {"python"},
  settings = {
    python = {
      analysis = {
        autoSearchPaths = true,
        diagnosticMode = "workspace",
        useLibraryCodeForTypes = true,
        typeCheckingMode = "basic",
      }
    }
  }
})
EOF
```

**Step 8: Update the main lspconfig with Pyright setup**
```bash
# Add Pyright to the main lspconfig
cat >> ~/.config/nvim/lua/plugins/configs/lspconfig.lua << 'EOF'

-- Configure pyright for Python
require("lspconfig").pyright.setup {
  on_init = M.on_init,
  on_attach = M.on_attach,
  capabilities = M.capabilities,
  filetypes = {"python"},
  settings = {
    python = {
      analysis = {
        autoSearchPaths = true,
        diagnosticMode = "workspace",
        useLibraryCodeForTypes = true,
        typeCheckingMode = "basic",
      }
    }
  }
}
EOF
```

**Step 9: First launch and setup**
```bash
# Launch Neovim for initial setup
nvim

# In Neovim, run these commands:
# :MasonInstallAll
# :TSUpdate
# :checkhealth

# Exit and relaunch
# :q!

nvim
```

## 🎨 My Custom Features

### 🌟 Special Features You'll Get:
1. **Transparent Background** - Clean, modern look
2. **Python Development Setup** - Full debugging, LSP, formatting
3. **Shiny NvimTree Highlights** - Beautiful file tree with colorful highlights
4. **Red Comments** - Comments are bright red for maximum visibility
5. **Custom Python Keybindings** - Quick run, debug, and test Python files
6. **Enhanced File Tree** - Git integration with special file highlighting

### 🐍 Python Development Features:
- **Pyright LSP** for intelligent code completion
- **Black** for code formatting
- **Ruff** and **MyPy** for linting
- **DAP (Debug Adapter Protocol)** for debugging
- **Custom run commands** for quick Python execution

### 🎯 Custom Commands Available:
- `:PyRun` - Run current Python file
- `:PyTerm` - Run Python file in terminal
- `:FixComments` - Force bright red comment colors
- `:MasonInstallAll` - Install all configured tools

## 🚨 Troubleshooting

### If plugins don't load:
```bash
# Remove lazy-lock.json and reinstall
rm ~/.config/nvim/lazy-lock.json
nvim +MasonInstallAll +TSUpdate +qa
```

### If LSP doesn't work:
```bash
# In Neovim
:Mason
# Install: pyright, black, mypy, ruff, debugpy
```

### If transparent background doesn't work:
```bash
# In Neovim
:hi Normal guibg=NONE ctermbg=NONE
```

### If colors are wrong:
```bash
# In Neovim
:FixComments
```

## 🎉 What You'll Have

After following this guide, you'll have:
- ✅ NvChad v2.0 base configuration
- ✅ My custom transparent theme
- ✅ All my keybindings and shortcuts
- ✅ Python development environment
- ✅ Beautiful shiny file tree
- ✅ Bright red comments
- ✅ Debugging capabilities
- ✅ Auto-formatting and linting
- ✅ All my custom commands and mappings

## 📞 Support

If you run into issues:
1. Check `:checkhealth`
2. Verify all prerequisites are installed
3. Make sure you're using Neovim 0.11+
4. Try removing `~/.local/share/nvim` and `~/.cache/nvim` and restart

Enjoy the same powerful Neovim setup! 🚀
