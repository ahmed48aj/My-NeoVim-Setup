# 🔥 Neovim Keybindings Reference (Ahmed's Configuration)

This is a comprehensive reference for all keybindings in my Neovim setup. The leader key is `<Space>`.

## 🎯 General Navigation & Editing

### Basic Movement & Editing
| Key | Mode | Action |
|-----|------|--------|
| `jj` | **Insert** | Exit insert mode (back to normal) |
| `j` | **Normal** | Move down (respects wrapped lines) |
| `k` | **Normal** | Move up (respects wrapped lines) |
| `<Up>` | **Normal/Visual** | Move up (respects wrapped lines) |
| `<Down>` | **Normal/Visual** | Move down (respects wrapped lines) |
| `<Esc>` | **Normal** | Clear search highlights |

### Insert Mode Navigation
| Key | Mode | Action |
|-----|------|--------|
| `<Ctrl-b>` | **Insert** | Go to beginning of line |
| `<Ctrl-e>` | **Insert** | Go to end of line |
| `<Ctrl-h>` | **Insert** | Move cursor left |
| `<Ctrl-l>` | **Insert** | Move cursor right |
| `<Ctrl-j>` | **Insert** | Move cursor down |
| `<Ctrl-k>` | **Insert** | Move cursor up |

### Window Management
| Key | Mode | Action |
|-----|------|--------|
| `<Ctrl-h>` | **Normal** | Switch to left window |
| `<Ctrl-l>` | **Normal** | Switch to right window |
| `<Ctrl-j>` | **Normal** | Switch to bottom window |
| `<Ctrl-k>` | **Normal** | Switch to top window |

### File Operations
| Key | Mode | Action |
|-----|------|--------|
| `<Ctrl-s>` | **Normal** | Save current file |
| `<Ctrl-c>` | **Normal** | Copy entire file to clipboard |
| `<leader>b` | **Normal** | Create new buffer |

### Visual Mode
| Key | Mode | Action |
|-----|------|--------|
| `<` | **Visual** | Indent left (stay in visual mode) |
| `>` | **Visual** | Indent right (stay in visual mode) |
| `p` | **Visual** | Paste without copying replaced text |

---

## 📁 File Tree (NvimTree)

| Key | Mode | Action |
|-----|------|--------|
| `<Ctrl-n>` | **Normal** | Toggle file tree |
| `<leader>e` | **Normal** | Focus file tree |

### Inside File Tree:
| Key | Action |
|-----|--------|
| `<Enter>` | Open file/folder |
| `o` | Open file/folder |
| `<Ctrl-v>` | Open file in vertical split |
| `<Ctrl-x>` | Open file in horizontal split |
| `<Tab>` | Preview file |
| `a` | Create new file/folder |
| `d` | Delete file/folder |
| `r` | Rename file/folder |
| `x` | Cut file/folder |
| `c` | Copy file/folder |
| `p` | Paste file/folder |
| `R` | Refresh tree |
| `H` | Toggle hidden files |
| `q` | Close tree |

---

## 🔍 Search & Navigation (Telescope)

### File Finding
| Key | Mode | Action |
|-----|------|--------|
| `<leader>ff` | **Normal** | Find files |
| `<leader>fa` | **Normal** | Find all files (including hidden/ignored) |
| `<leader>fo` | **Normal** | Find recent/old files |
| `<leader>fb` | **Normal** | Find open buffers |
| `<leader>fh` | **Normal** | Find help pages |
| `<leader>fz` | **Normal** | Find text in current buffer |

### Text Search
| Key | Mode | Action |
|-----|------|--------|
| `<leader>fw` | **Normal** | Live grep (search text in project) |
| `<leader>ma` | **Normal** | Find bookmarks/marks |

### Git Integration
| Key | Mode | Action |
|-----|------|--------|
| `<leader>cm` | **Normal** | Browse git commits |
| `<leader>gt` | **Normal** | Git status |

### Themes & UI
| Key | Mode | Action |
|-----|------|--------|
| `<leader>th` | **Normal** | Switch NvChad themes |
| `<leader>pt` | **Normal** | Pick hidden terminal |

---

## 🐛 LSP (Language Server Protocol)

### Code Navigation
| Key | Mode | Action |
|-----|------|--------|
| `gd` | **Normal** | Go to definition |
| `gD` | **Normal** | Go to declaration |
| `gi` | **Normal** | Go to implementation |
| `gr` | **Normal** | Show references |
| `K` | **Normal** | Show hover documentation |
| `<leader>D` | **Normal** | Go to type definition |

### Code Actions
| Key | Mode | Action |
|-----|------|--------|
| `<leader>ca` | **Normal/Visual** | Show code actions |
| `<leader>ra` | **Normal** | Rename symbol |
| `<leader>fm` | **Normal** | Format code |
| `<leader>ls` | **Normal** | Show signature help |

### Diagnostics
| Key | Mode | Action |
|-----|------|--------|
| `[d` | **Normal** | Go to previous diagnostic |
| `]d` | **Normal** | Go to next diagnostic |
| `<leader>lf` | **Normal** | Show floating diagnostic |
| `<leader>q` | **Normal** | Show diagnostics in location list |

### Workspace Management
| Key | Mode | Action |
|-----|------|--------|
| `<leader>wa` | **Normal** | Add workspace folder |
| `<leader>wr` | **Normal** | Remove workspace folder |
| `<leader>wl` | **Normal** | List workspace folders |

---

## 🐍 Python Development

### Running Python Code
| Key | Mode | Action |
|-----|------|--------|
| `<leader>pr` | **Normal** | Run current Python file |
| `<leader>pt` | **Normal** | Run Python file in terminal |
| `<leader>pi` | **Normal** | Run Python interactive mode |

### Python Commands
| Command | Action |
|---------|--------|
| `:PyRun` | Run current Python file |
| `:PyTerm` | Run Python file in terminal |

---

## 🐛 Debugging (DAP - Debug Adapter Protocol)

### Breakpoints & Control
| Key | Mode | Action |
|-----|------|--------|
| `<leader>db` | **Normal** | Toggle breakpoint |
| `<leader>dc` | **Normal** | Start/Continue debugging |
| `<leader>dr` | **Normal** | Restart debugging |
| `<leader>dt` | **Normal** | Terminate debugging |
| `<leader>du` | **Normal** | Toggle debug UI |

### Stepping Through Code
| Key | Mode | Action |
|-----|------|--------|
| `<leader>dso` | **Normal** | Step over |
| `<leader>dsi` | **Normal** | Step into |
| `<leader>dsO` | **Normal** | Step out |

### Python-Specific Debug
| Key | Mode | Action |
|-----|------|--------|
| `<leader>dpr` | **Normal** | Debug Python test method |
| `<leader>dpc` | **Normal** | Debug Python test class |
| `<leader>dpf` | **Normal** | Debug Python selection |

---

## 💬 Comments

| Key | Mode | Action |
|-----|------|--------|
| `<leader>/` | **Normal** | Toggle line comment |
| `<leader>/` | **Visual** | Toggle comment on selection |
| `gcc` | **Normal** | Toggle line comment |
| `gc` | **Normal/Visual** | Toggle linewise comment |
| `gbc` | **Normal** | Toggle block comment |
| `gb` | **Normal/Visual** | Toggle blockwise comment |

---

## 📄 Buffer Management

### Buffer Navigation
| Key | Mode | Action |
|-----|------|--------|
| `<Tab>` | **Normal** | Go to next buffer |
| `<Shift-Tab>` | **Normal** | Go to previous buffer |
| `<leader>x` | **Normal** | Close current buffer |

---

## 🖥️ Terminal

### Terminal Toggle (NvTerm)
| Key | Mode | Action |
|-----|------|--------|
| `<Alt-i>` | **Normal/Terminal** | Toggle floating terminal |
| `<Alt-h>` | **Normal/Terminal** | Toggle horizontal terminal |
| `<Alt-v>` | **Normal/Terminal** | Toggle vertical terminal |

### New Terminal
| Key | Mode | Action |
|-----|------|--------|
| `<leader>h` | **Normal** | New horizontal terminal |
| `<leader>v` | **Normal** | New vertical terminal |

### Terminal Mode
| Key | Mode | Action |
|-----|------|--------|
| `<Ctrl-x>` | **Terminal** | Exit terminal mode |

---

## 🎨 UI & Display

### Line Numbers
| Key | Mode | Action |
|-----|------|--------|
| `<leader>n` | **Normal** | Toggle line numbers |
| `<leader>rn` | **Normal** | Toggle relative line numbers |

### Help & Cheatsheet
| Key | Mode | Action |
|-----|------|--------|
| `<leader>ch` | **Normal** | Show NvChad cheatsheet |
| `<leader>wK` | **Normal** | Show all keymaps (WhichKey) |
| `<leader>wk` | **Normal** | Query specific keymap |

---

## 🎯 Git Integration (GitSigns)

### Navigation
| Key | Mode | Action |
|-----|------|--------|
| `]c` | **Normal** | Next git hunk |
| `[c` | **Normal** | Previous git hunk |

### Git Actions
| Key | Mode | Action |
|-----|------|--------|
| `<leader>rh` | **Normal** | Reset hunk |
| `<leader>ph` | **Normal** | Preview hunk |
| `<leader>gb` | **Normal** | Git blame line |
| `<leader>td` | **Normal** | Toggle deleted lines |

---

## 🔧 Special Features & Commands

### Custom Commands
| Command | Action |
|---------|--------|
| `:FixComments` | Force bright red comment colors |
| `:MasonInstallAll` | Install all configured LSP/tools |
| `:NvCheatsheet` | Show keybinding cheatsheet |
| `:Telescope themes` | Browse available themes |

### Context & Indentation
| Key | Mode | Action |
|-----|------|--------|
| `<leader>cc` | **Normal** | Jump to current context (indent) |

---

## 🎨 Color & Theme Features

### My Custom Features:
- **Transparent Background** - Neovim background is transparent
- **Bright Red Comments** - All comments are bright red and bold
- **Shiny NvimTree** - File tree has colorful highlights for different file types
- **Enhanced Git Integration** - Git status shown with colors in file tree

### Special Highlights:
- **Gold highlight** for current file in tree
- **Bright colors** for different file states (modified, staged, etc.)
- **Transparent terminal** integration
- **Custom Python syntax highlighting**

---

## 💡 Tips & Tricks

1. **Leader Key**: The `<leader>` key is **Space**, so `<leader>ff` means `Space + f + f`
2. **Quick Exit**: Use `jj` in insert mode to quickly exit to normal mode
3. **File Navigation**: Use `<Ctrl-n>` to toggle file tree, then use `<leader>e` to focus it
4. **Search Everything**: `<leader>ff` for files, `<leader>fw` for text search
5. **Python Workflow**: `<leader>pr` to run, `<leader>db` to debug
6. **Git Workflow**: `]c` and `[c` to navigate changes, `<leader>ph` to preview
7. **Terminal**: `<Alt-i>` for floating terminal, perfect for quick commands
8. **Buffer Management**: `<Tab>` and `<Shift-Tab>` to switch between files
9. **Format Code**: `<leader>fm` to format current file
10. **Help**: `<leader>ch` shows the built-in cheatsheet

---

## 🚀 Advanced Workflows

### Python Development Workflow:
1. `<Ctrl-n>` - Open file tree
2. Navigate to Python file and open
3. `<leader>pr` - Run the file
4. `<leader>db` - Set breakpoints
5. `<leader>dc` - Start debugging
6. `<leader>fm` - Format code before saving

### File Management Workflow:
1. `<leader>ff` - Find files quickly
2. `<leader>fw` - Search for specific text
3. `<Tab>`/`<Shift-Tab>` - Switch between open files
4. `<leader>x` - Close unwanted buffers

### Code Navigation Workflow:
1. `gd` - Go to definition
2. `gr` - Show all references  
3. `K` - Check documentation
4. `<leader>ca` - Apply code fixes
5. `<leader>ra` - Rename variables

This setup provides a complete, modern development environment with all the shortcuts you need! 🎉
